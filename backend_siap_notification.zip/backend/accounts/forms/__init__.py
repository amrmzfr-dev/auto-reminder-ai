from .admin_forms import *
from .installer_forms import *
from .installation_forms import *
from .test_forms import *